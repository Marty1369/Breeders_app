import React from "react";

/**
 * Card — the base surface. White, rounded, thin stone border, no
 * shadow by default (borders do the elevation work). `feature` uses
 * a larger radius; `hero` is the deep-green inverted variant.
 */
export function Card({ children, variant = "default", padded = true, style = {}, ...rest }) {
  const variants = {
    default: {
      background: "var(--surface)",
      border: "1px solid var(--border-card)",
      borderRadius: "var(--radius-xl)",
      color: "var(--ink-900)",
    },
    feature: {
      background: "var(--surface)",
      border: "1px solid var(--border-card)",
      borderRadius: "var(--radius-2xl)",
      color: "var(--ink-900)",
    },
    hero: {
      background: "var(--green-900)",
      border: "none",
      borderRadius: "var(--radius-2xl)",
      color: "#fff",
    },
  };
  return (
    <div
      style={{
        fontFamily: "var(--font-sans)",
        padding: padded ? "14px 17px" : 0,
        ...variants[variant],
        ...style,
      }}
      {...rest}
    >
      {children}
    </div>
  );
}

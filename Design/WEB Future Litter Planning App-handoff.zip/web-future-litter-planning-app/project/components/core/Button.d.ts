import * as React from "react";

/**
 * The primary action control for Litter Planner.
 * @startingPoint section="Core" subtitle="Primary / secondary / ghost / danger action button" viewport="320x64"
 */
export interface ButtonProps {
  children: React.ReactNode;
  /** Visual weight. Default "primary". */
  variant?: "primary" | "secondary" | "ghost" | "danger";
  /** Control size. Default "md". */
  size?: "sm" | "md" | "lg";
  /** Optional leading glyph (unicode or emoji), e.g. "＋" or "⟳". */
  icon?: React.ReactNode;
  disabled?: boolean;
  onClick?: () => void;
  style?: React.CSSProperties;
}

export function Button(props: ButtonProps): JSX.Element;

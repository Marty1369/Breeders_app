Base surface for grouped content — wrap stats, lists, and forms. Elevation comes from the border, not a shadow.

```jsx
<Card>Standard white card</Card>
<Card variant="hero"><div>Day 15 of 63</div></Card>
```

Variants: `default`, `feature` (softer/larger radius for dashboard tiles), `hero` (deep-green `--green-900`, white text — used for the active-litter summary). Set `padded={false}` when the card holds full-bleed list rows with their own padding.

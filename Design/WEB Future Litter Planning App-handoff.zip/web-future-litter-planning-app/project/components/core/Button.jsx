import React from "react";

/**
 * Button — the primary action control. Extra-bold label, generous
 * radius. Primary carries a green-tinted shadow; secondary is an
 * outline; ghost is text-only; danger is a red outline.
 */
export function Button({
  children,
  variant = "primary",
  size = "md",
  icon = null,
  disabled = false,
  onClick,
  style = {},
  ...rest
}) {
  const sizes = {
    sm: { padding: "8px 14px", fontSize: 12 },
    md: { padding: "13px 17px", fontSize: 14 },
    lg: { padding: "15px 20px", fontSize: 15 },
  };
  const variants = {
    primary: {
      background: "var(--green-700)",
      color: "#fff",
      border: "none",
      boxShadow: "var(--shadow-button)",
    },
    secondary: {
      background: "var(--surface)",
      color: "var(--green-700)",
      border: "1.5px solid var(--green-700)",
    },
    ghost: {
      background: "transparent",
      color: "var(--green-700)",
      border: "none",
    },
    danger: {
      background: "var(--surface)",
      color: "var(--red-600)",
      border: "1px solid var(--red-border)",
    },
  };
  return (
    <button
      onClick={disabled ? undefined : onClick}
      disabled={disabled}
      style={{
        display: "inline-flex",
        alignItems: "center",
        justifyContent: "center",
        gap: 8,
        fontFamily: "var(--font-sans)",
        fontWeight: 800,
        borderRadius: "var(--radius-md)",
        cursor: disabled ? "default" : "pointer",
        opacity: disabled ? 0.45 : 1,
        whiteSpace: "nowrap",
        lineHeight: 1,
        ...sizes[size],
        ...variants[variant],
        ...style,
      }}
      {...rest}
    >
      {icon ? <span style={{ fontSize: "1.05em" }}>{icon}</span> : null}
      {children}
    </button>
  );
}

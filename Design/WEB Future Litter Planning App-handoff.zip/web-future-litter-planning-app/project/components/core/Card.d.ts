import * as React from "react";

/** Base surface container for content blocks. */
export interface CardProps {
  children: React.ReactNode;
  /** "default" (white, radius-xl), "feature" (white, radius-2xl), "hero" (deep-green inverted). */
  variant?: "default" | "feature" | "hero";
  /** Apply standard 14×17 inset. Default true. */
  padded?: boolean;
  style?: React.CSSProperties;
}

export function Card(props: CardProps): JSX.Element;

Primary action control — use for the main affirmative action on a screen, sheet, or card; downgrade secondary actions to `secondary`/`ghost`.

```jsx
<Button variant="primary" icon="＋" onClick={addTask}>New task</Button>
<Button variant="secondary" icon="⟳">New repeat</Button>
<Button variant="ghost">Cancel</Button>
<Button variant="danger">Delete</Button>
```

Variants: `primary` (green fill + tinted shadow), `secondary` (green outline), `ghost` (text only), `danger` (red outline, destructive). Sizes: `sm` / `md` / `lg`. Labels are always extra-bold (800). Keep labels short; the button never wraps.

import React from "react";

/**
 * Avatar — a team member's identity chip: two-letter initials on a
 * per-member color. Ring highlights the active ("I am") member.
 */
export function Avatar({ initials, color = "var(--member-1)", size = 34, active = false, onClick, style = {} }) {
  return (
    <div
      onClick={onClick}
      style={{
        width: size,
        height: size,
        flex: "none",
        borderRadius: "var(--radius-pill)",
        background: color,
        color: "#fff",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        fontFamily: "var(--font-sans)",
        fontSize: size * 0.32,
        fontWeight: 800,
        boxSizing: "border-box",
        border: active ? "2.5px solid var(--green-700)" : "2.5px solid transparent",
        opacity: active ? 1 : 0.85,
        cursor: onClick ? "pointer" : "default",
        ...style,
      }}
    >
      {initials}
    </div>
  );
}

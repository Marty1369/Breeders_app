import * as React from "react";

/** Team member identity chip with initials on a per-member color. */
export interface AvatarProps {
  /** Two-letter initials, e.g. "Au". */
  initials: string;
  /** One of the --member-* colors. */
  color?: string;
  /** Pixel diameter. Default 34. */
  size?: number;
  /** Draw the active-member green ring. */
  active?: boolean;
  onClick?: () => void;
  style?: React.CSSProperties;
}

export function Avatar(props: AvatarProps): JSX.Element;

import React from "react";

/**
 * ProgressBar — a thin rounded track with a green fill. On dark
 * surfaces (inside a hero card) pass tone="onDark".
 */
export function ProgressBar({ value = 0, tone = "default", height = 5, style = {} }) {
  const pct = Math.max(0, Math.min(100, value));
  const track = tone === "onDark" ? "rgba(255,255,255,0.18)" : "var(--green-sage)";
  const fill = tone === "onDark" ? "var(--green-300)" : "var(--green-700)";
  return (
    <div style={{ height, borderRadius: 3, background: track, overflow: "hidden", ...style }}>
      <div style={{ width: pct + "%", height: "100%", background: fill, borderRadius: 3 }} />
    </div>
  );
}

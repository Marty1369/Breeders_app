Thin progress track — litter day-of-63, payment completion, gestation. Use `tone="onDark"` inside a `hero` Card.

```jsx
<ProgressBar value={24} />
<ProgressBar value={72} tone="onDark" />
```

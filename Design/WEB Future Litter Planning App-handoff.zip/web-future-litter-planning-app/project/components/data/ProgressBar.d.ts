import * as React from "react";

/** Thin rounded progress/percentage track. */
export interface ProgressBarProps {
  /** 0–100. */
  value?: number;
  /** "default" (on light) or "onDark" (inside a hero card). */
  tone?: "default" | "onDark";
  /** Track height in px. Default 5. */
  height?: number;
  style?: React.CSSProperties;
}

export function ProgressBar(props: ProgressBarProps): JSX.Element;

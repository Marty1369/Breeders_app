Team-member identity chip — used in the "I am" picker, assignee lists, and rotation displays. Each member has a fixed `--member-*` color.

```jsx
<Avatar initials="Au" color="var(--member-2)" active />
<Avatar initials="An" color="var(--member-1)" onClick={pick} />
```

Set `active` for the current user (green ring, full opacity). Size defaults to 34px; use ~20px inline in chips, ~40px in headers.

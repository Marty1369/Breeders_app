import * as React from "react";

/** Selectable pill for choice sets (single or multi). */
export interface ChipToggleProps {
  children: React.ReactNode;
  selected?: boolean;
  /** Selected appearance: "tint" (green outline+tint) or "solid" (filled green). Default "tint". */
  selectedStyle?: "tint" | "solid";
  /** Optional leading element (e.g. a small Avatar). */
  icon?: React.ReactNode;
  onClick?: () => void;
  style?: React.CSSProperties;
}

export function ChipToggle(props: ChipToggleProps): JSX.Element;

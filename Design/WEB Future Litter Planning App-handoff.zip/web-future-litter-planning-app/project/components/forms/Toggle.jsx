import React from "react";

/**
 * Toggle — the pill switch used throughout sheets (Repeat, Kennel-
 * level, Default task). Green when on, stone track when off.
 */
export function Toggle({ checked = false, onChange, size = "md", style = {} }) {
  const dims = size === "sm"
    ? { w: 36, h: 22, k: 17, on: 16.5, off: 2.5 }
    : { w: 40, h: 24, k: 18, on: 19, off: 3 };
  return (
    <div
      onClick={() => onChange && onChange(!checked)}
      style={{
        width: dims.w,
        height: dims.h,
        flex: "none",
        borderRadius: "var(--radius-pill)",
        background: checked ? "var(--green-700)" : "var(--line-track)",
        position: "relative",
        cursor: "pointer",
        transition: "background .15s",
        ...style,
      }}
    >
      <div
        style={{
          position: "absolute",
          top: (dims.h - dims.k) / 2,
          left: checked ? dims.on : dims.off,
          width: dims.k,
          height: dims.k,
          borderRadius: "50%",
          background: "#fff",
          transition: "left .15s",
        }}
      />
    </div>
  );
}

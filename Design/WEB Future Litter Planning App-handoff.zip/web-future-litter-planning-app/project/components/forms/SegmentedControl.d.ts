import * as React from "react";

export interface SegmentOption {
  value: string;
  label: string;
}

/** Compact 2–3 option segmented switch on a sage track. */
export interface SegmentedControlProps {
  options: SegmentOption[];
  value: string;
  onChange?: (value: string) => void;
  style?: React.CSSProperties;
}

export function SegmentedControl(props: SegmentedControlProps): JSX.Element;

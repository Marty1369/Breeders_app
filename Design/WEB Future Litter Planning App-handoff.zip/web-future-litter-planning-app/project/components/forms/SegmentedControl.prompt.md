Compact segmented switch for 2–3 short, mutually exclusive options — mobile litter sub-nav, times-per-day, AM/PM.

```jsx
<SegmentedControl
  value={tab}
  onChange={setTab}
  options={[{value:"pups",label:"Puppies"},{value:"weigh",label:"Weigh-in"},{value:"docs",label:"Docs"}]}
/>
```

For longer or more numerous options use a row of `ChipToggle` instead.

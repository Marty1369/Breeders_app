import * as React from "react";

/** Pill switch for boolean settings. */
export interface ToggleProps {
  checked?: boolean;
  onChange?: (next: boolean) => void;
  /** "md" (40×24) or "sm" (36×22). */
  size?: "sm" | "md";
  style?: React.CSSProperties;
}

export function Toggle(props: ToggleProps): JSX.Element;

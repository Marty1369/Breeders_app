import React from "react";

/**
 * ChipToggle — a selectable pill used for multi/single choice sets
 * (assignees, frequency, phase, category). Two selected styles:
 * "tint" (green outline + tint) and "solid" (filled deep-green).
 */
export function ChipToggle({ children, selected = false, selectedStyle = "tint", icon = null, onClick, style = {} }) {
  const base = { background: "var(--surface)", color: "var(--ink-500)", border: "1px solid var(--line-200)" };
  const sel =
    selectedStyle === "solid"
      ? { background: "var(--green-900)", color: "#fff", border: "1px solid var(--green-900)" }
      : { background: "var(--green-100)", color: "var(--green-900)", border: "1.5px solid var(--green-700)" };
  const s = selected ? sel : base;
  return (
    <div
      onClick={onClick}
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: 6,
        fontFamily: "var(--font-sans)",
        fontSize: 11.5,
        fontWeight: 700,
        padding: icon ? "5px 11px 5px 6px" : "6px 12px",
        borderRadius: "var(--radius-pill)",
        cursor: "pointer",
        ...s,
        ...style,
      }}
    >
      {icon}
      {children}
    </div>
  );
}

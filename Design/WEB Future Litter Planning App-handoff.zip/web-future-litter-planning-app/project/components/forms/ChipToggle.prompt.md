Selectable pill for choice groups — assignees (with an Avatar `icon`), frequency, phase, expense category, coat color.

```jsx
<ChipToggle selected selectedStyle="solid">Daily</ChipToggle>
<ChipToggle selected icon={<Avatar initials="Au" size={20} color="var(--member-2)" />}>Aurelija</ChipToggle>
<ChipToggle>Weekly</ChipToggle>
```

Use `selectedStyle="tint"` for multi-select sets (assignees) and `"solid"` for single-select segmented choices (frequency, phase).

import React from "react";

/**
 * SegmentedControl — a compact 2–3 option switch on a sage track;
 * the selected segment lifts to white with a soft shadow. Used for
 * the mobile litter sub-nav (Puppies / Weigh-in / Docs) and times-
 * per-day (1× / 2× / 3×).
 */
export function SegmentedControl({ options, value, onChange, style = {} }) {
  return (
    <div
      style={{
        display: "inline-flex",
        gap: 3,
        background: "var(--green-sage)",
        borderRadius: "var(--radius-md)",
        padding: 3,
        fontFamily: "var(--font-sans)",
        ...style,
      }}
    >
      {options.map((o) => {
        const active = o.value === value;
        return (
          <div
            key={o.value}
            onClick={() => onChange && onChange(o.value)}
            style={{
              padding: "7px 13px",
              borderRadius: "var(--radius-sm)",
              fontSize: 12,
              fontWeight: 800,
              cursor: "pointer",
              color: active ? "var(--ink-900)" : "var(--ink-500)",
              background: active ? "var(--surface)" : "transparent",
              boxShadow: active ? "var(--shadow-pop)" : "none",
            }}
          >
            {o.label}
          </div>
        );
      })}
    </div>
  );
}

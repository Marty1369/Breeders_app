Boolean switch — Repeat on/off, Kennel-level, Default task, Default document. Usually sits in a `--surface-row` block with a label to its left.

```jsx
<Toggle checked={repeat} onChange={setRepeat} />
<Toggle checked={kennel} onChange={setKennel} size="sm" />
```

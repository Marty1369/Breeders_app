import React from "react";

/**
 * StatusPill — a compact rounded status/label chip. Tone maps to the
 * semantic color pairs. `solid` inverts to a filled deep-green pill
 * (used for terminal states like PAID IN FULL / HANDED OVER).
 */
export function StatusPill({ children, tone = "neutral", solid = false, style = {} }) {
  const tones = {
    done: { background: "var(--green-100)", color: "var(--green-700)" },
    warn: { background: "var(--amber-100)", color: "var(--amber-700)" },
    neutral: { background: "var(--green-sage)", color: "var(--ink-600)" },
    info: { background: "#e8eef7", color: "var(--member-4)" },
  };
  const s = solid
    ? { background: "var(--green-900)", color: "#fff" }
    : tones[tone] || tones.neutral;
  return (
    <span
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: 5,
        fontFamily: "var(--font-sans)",
        fontSize: 9,
        fontWeight: 800,
        letterSpacing: "0.03em",
        padding: "3px 8px",
        borderRadius: "var(--radius-pill)",
        whiteSpace: "nowrap",
        ...s,
        ...style,
      }}
    >
      {children}
    </span>
  );
}

import * as React from "react";

/**
 * Compact status / label chip.
 * @startingPoint section="Feedback" subtitle="Status chip — done / warn / neutral / info / solid" viewport="300x48"
 */
export interface StatusPillProps {
  children: React.ReactNode;
  /** Semantic color pair. Default "neutral". */
  tone?: "done" | "warn" | "neutral" | "info";
  /** Inverted filled deep-green pill for terminal states. Overrides tone. */
  solid?: boolean;
  style?: React.CSSProperties;
}

export function StatusPill(props: StatusPillProps): JSX.Element;

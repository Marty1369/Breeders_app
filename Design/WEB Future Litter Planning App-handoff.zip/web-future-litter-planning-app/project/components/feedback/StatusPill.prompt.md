Small status/label chip — recurrence badges (⟳ DAILY), puppy status (RESERVED), overdue flags, phase tags.

```jsx
<StatusPill tone="done">⟳ DAILY</StatusPill>
<StatusPill tone="warn">OVERDUE</StatusPill>
<StatusPill tone="neutral">AVAILABLE</StatusPill>
<StatusPill solid>PAID IN FULL</StatusPill>
```

Text is uppercase 800-weight nano (9px). Tones: `done` (green tint), `warn` (amber), `neutral` (sage), `info` (blue). `solid` = filled deep-green for terminal/complete states.

import * as React from "react";

/**
 * The check-off list row — the core interaction of Litter Planner.
 * @startingPoint section="Lists" subtitle="Check-off row: status box + title/meta + trailing" viewport="380x60"
 */
export interface CheckRowProps {
  title: React.ReactNode;
  /** Secondary meta line (time · assignee · status). */
  meta?: React.ReactNode;
  /** Visual + interaction state of the status box. */
  state?: "done" | "skip" | "missed" | "due";
  /** Trailing content — a StatusPill, Avatar, or action links. */
  trailing?: React.ReactNode;
  /** Toggle the status box. */
  onToggle?: () => void;
  /** Open the item's detail/editor (title/meta area). */
  onOpen?: () => void;
  /** Show the bottom hairline (omit on last row). Default true. */
  divider?: boolean;
  style?: React.CSSProperties;
}

export function CheckRow(props: CheckRowProps): JSX.Element;

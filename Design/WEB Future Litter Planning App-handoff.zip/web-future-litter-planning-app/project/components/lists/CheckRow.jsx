import React from "react";

/**
 * CheckRow — the check-off list row that is the heart of the app.
 * A tappable status box (done / skipped / missed / due), a title +
 * meta stack, and optional trailing content (badge, avatar).
 */
export function CheckRow({
  title,
  meta,
  state = "due",
  trailing = null,
  onToggle,
  onOpen,
  divider = true,
  style = {},
}) {
  const done = state === "done";
  const skip = state === "skip";
  const box = {
    done: { bg: "var(--green-700)", border: "1px solid var(--green-700)", mark: "✓", markColor: "#fff" },
    skip: { bg: "var(--surface-2)", border: "2px solid var(--line-track)", mark: "–", markColor: "var(--ink-300)" },
    missed: { bg: "var(--surface)", border: "2px solid var(--amber-500)", mark: "", markColor: "var(--ink-300)" },
    due: { bg: "var(--surface)", border: "2px solid #cfd4cf", mark: "", markColor: "var(--ink-300)" },
  }[state] || {};
  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        gap: 12,
        padding: "12px 16px",
        borderBottom: divider ? "1px solid var(--border-hairline)" : "none",
        fontFamily: "var(--font-sans)",
        ...style,
      }}
    >
      <div
        onClick={onToggle}
        style={{
          width: 22,
          height: 22,
          flex: "none",
          borderRadius: "var(--radius-xs)",
          background: box.bg,
          border: box.border,
          boxSizing: "border-box",
          display: "grid",
          placeItems: "center",
          color: box.markColor,
          fontSize: 11,
          fontWeight: 800,
          cursor: "pointer",
        }}
      >
        {box.mark}
      </div>
      <div style={{ flex: 1, minWidth: 0, cursor: onOpen ? "pointer" : "default" }} onClick={onOpen}>
        <div
          style={{
            fontSize: 13,
            fontWeight: 700,
            color: done || skip ? "var(--ink-300)" : "var(--ink-900)",
            textDecoration: done ? "line-through" : "none",
          }}
        >
          {title}
        </div>
        {meta ? (
          <div style={{ fontSize: 10.5, fontWeight: 600, color: "var(--ink-400)", marginTop: 1 }}>{meta}</div>
        ) : null}
      </div>
      {trailing}
    </div>
  );
}

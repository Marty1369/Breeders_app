The check-off row — tasks, recurring occurrences, and plan items. Stack rows inside a bordered `Card` with `padded={false}`.

```jsx
<CheckRow
  title="Weigh puppies"
  meta="20:00 · Simona's turn (rotation)"
  state="due"
  trailing={<StatusPill tone="done">⟳ DAILY</StatusPill>}
  onToggle={toggle}
  onOpen={openEditor}
/>
<CheckRow title="Whelping box temperature" meta="daily · 28.5 °C · Aurelija" state="done" divider={false} />
```

States: `done` (green box + strikethrough), `skip` (dash), `missed` (amber ring), `due` (grey ring). Tapping the box calls `onToggle`; tapping the text calls `onOpen`.

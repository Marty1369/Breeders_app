# Litter Planner — Design System

The visual language of **Litter Planner**, a responsive kennel-management PWA for planning and running dog litters (breeding, whelping, rearing, sale). This design system was extracted from the live app at `Litter Planner App.dc.html` (project root), which is the source of truth for every value here.

> Scope note: this is a **visual style reference** only. Sample names (Mona, Flying Aussie Kennel, team members) are placeholder content from the app, not facts about any user.

## Sources
- `Litter Planner App.dc.html` — the full, interactive responsive app (desktop + mobile). All tokens, components and screens here are lifted from it.

---

## CONTENT FUNDAMENTALS
- **Tone:** practical, calm, operational — a working tool for busy breeders, not marketing. Short, concrete labels ("Weigh puppies", "New repeat", "Mark handed over").
- **Voice:** second-person and imperative for actions ("Log heat today", "Attach document"). Third-person for state ("Marlow is not gaining weight").
- **Casing:** Sentence case for titles and body. **UPPERCASE micro-labels** with wide tracking (0.07–0.08em, 800 weight) for section headers and badges ("MORNING · 08:00", "WEIGHT ALERT", "⟳ DAILY").
- **Numbers matter:** grams, days, euros and dates are first-class — shown big and bold. Dates are terse ("Aug 3", "Tue, Jul 7", "T–5 to whelping").
- **Domain vocabulary:** litter, dam/sire, whelping, weaning, handover, heat, check-off, rotation, kennel-level. Litter identity is a letter (Litter M → puppies named with M).
- **Emoji/glyphs:** no decorative emoji. A small set of **unicode glyphs** act as functional icons: `⟳` recurring, `✓` done, `＋` add, `⚠`/`!` alert, `♀`/`♂` sex, `€` money, `📎` attachment, `◈ ▣ ▤ ⌂ ∿ ❋ ☰ ▦ ↺` for nav.

## VISUAL FOUNDATIONS
- **Color:** warm and natural. A single **brand green** (`#17805a` primary, `#123f2d` deep ink) over a **warm stone** canvas (`#f4f3ee`) and white cards. Text is a warm charcoal ramp (`#191c1a → #b8bdb8`), never pure black/grey. Amber (`#b97324`) = attention/overdue, red (`#b95724`) = destructive. Members and coats have their own fixed swatches.
- **Type:** **Manrope** only, weight-led. Extra-bold (800) does the heavy lifting for titles, numbers and buttons; 600–700 for body; wide-tracked uppercase for micro-labels. See `tokens/typography.css`.
- **Elevation:** borders first. Cards are white with a 1px stone border and **no shadow**. Shadows are reserved for primary buttons (green-tinted), the mobile FAB, and overlays (modals/sheets).
- **Radius:** generous. Pills (99px) for chips/badges/avatars/toggles; 11–16px soft rectangles for buttons, rows and cards; 18px modals; 22px bottom sheets. Checkboxes are small 7px squares.
- **Layout:** flex/grid with `gap` drives spacing (not margins). Desktop = fixed sidebar + scrolling content; mobile = fixed bottom tab bar + FAB. Loose 4px rhythm.
- **Hero surface:** the one inverted element — a deep-green (`#123f2d`) card with white text and a mint (`#7fd4ae`) progress fill, used for the active-litter summary.
- **States:** hover/press lean on opacity and tint changes; the green pill toggle slides (150ms). "Done" rows strike through and mute to `#9aa19c`. Occurrence markers: green = done, amber = skipped, terracotta = missed.
- **Backgrounds:** flat warm colors only — no gradients, no imagery, no texture, no blur.

## ICONOGRAPHY
No icon font or SVG set ships with the app — icons are **unicode glyphs** rendered in Manrope (see the list above), sized to context and colored with text tokens. `♀`/`♂` mark puppy sex; `⟳` is the recurrence signature, appearing on every repeating item and badge. **There is no brand logo** in the source; the mark is a small green rounded square holding a 2×2 dot grid (a stylized litter). Where a wordmark is needed, set "Litter Planner" in Manrope 800. If you have a real logo, drop it in `assets/` and update this section.

---

## Index / manifest
- `styles.css` — global entry (import this). Pulls in everything below.
- `tokens/` — `fonts.css`, `colors.css`, `typography.css`, `spacing.css`, `radius.css`, `shadow.css`.
- `guidelines/` — foundation specimen cards (Colors, Type, Spacing, Foundations).
- `components/` — reusable primitives, grouped:
  - `core/` — **Button**, **Card**
  - `feedback/` — **StatusPill**
  - `forms/` — **Toggle**, **ChipToggle**, **SegmentedControl**
  - `data/` — **Avatar**, **ProgressBar**
  - `lists/` — **CheckRow** (the core check-off row)
- `ui_kits/litter-planner/` — desktop dashboard recreation + notes.
- `SKILL.md` — portable skill wrapper.

## Intentional additions
The app defines no formal component library, so the component inventory above was distilled from the recurring UI patterns actually used in `Litter Planner App.dc.html` (check-off rows, status pills, chip/segmented pickers, the pill toggle, member avatars, progress tracks). No primitives were invented beyond what the app uses.

## Caveats
- **Font**: Manrope is loaded from Google Fonts (it is the app's real face); no binaries are bundled. Swap in self-hosted `.woff2` if you need offline use.
- **No compiler in this project**: component preview cards are static token-driven HTML rather than bundle-mounted, so they render anywhere. When these files live in a project flagged as a Design System, the `.jsx` + `.d.ts` compile into the component library automatically.
- **No logo asset** was provided — see ICONOGRAPHY.

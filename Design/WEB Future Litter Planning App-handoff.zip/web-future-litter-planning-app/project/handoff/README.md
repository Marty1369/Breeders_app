# Litter Planner — Design Handoff (v1.6)

Design package for a kennel litter-planning Android app (PWA or native). Built for a 4–5 person team ("space") managing dog litters: timeline of ~78 auto-scheduled tasks, dog & puppy records, document generation, expenses, push notifications.

**Source of truth for visuals:** `Litter App Design.dc.html` in the design project — screen ids (2a…12d) referenced throughout. All screens are 412×880 Android, inline-styled, directly inspectable. Flow maps: 9a (navigation), 12a (lifecycle).

## Files
- `SPEC.md` — consolidated build spec v1.6: data model, scheduling engine, notifications, documents, auth
- `SCREENS.md` — full screen inventory with ids and states
- `FLOWS.md` — navigation map and key user journeys
- `DECISIONS.md` — resolved product decisions (nav, People vs Owners, MVP scope, sad paths)

## Ground rules for the implementing agent
1. The **record is the single source of truth** — documents are immutable renders; fix data in records and regenerate. No in-document editing.
2. **Manual dates always override formulas** and re-cascade downstream task dates (except pinned tasks).
3. One space, **no roles in MVP** — every member is equal; leave a `role` field on User for later RBAC.
4. Owners are **contact records, not app users** — they are never notified in MVP.
5. Dogs (dam/sire) are **first-class records** with heat prediction — litters reference them, not text names.
6. Visual style: white `#fafaf9` background, cards `#fff` with `#ebebe6` borders, accent green `#17805a`, amber warnings `#b97324`/`#d9a05c`, danger `#b93a2e`, font Manrope, radius 12–14px, min touch target 44px.

## Suggested repo layout
```
docs/design/   ← these four .md files
docs/design/screens/  ← optional: screenshots exported from the design canvas
```

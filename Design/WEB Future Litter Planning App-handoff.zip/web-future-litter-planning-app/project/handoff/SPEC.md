# Build Specification v1.6 (consolidated)

## Data model

```
Space         id, name, inviteToken (rotating, 7-day expiry)
User          id, spaceId, name, email, phone, avatarColor,
              notifPrefs{push,email, assignments, milestones, teammatesTasks},
              pushTokens[], role? (unused in MVP)
Dog           id, spaceId, name, sex, breed, dob, regNo(LŠVK), chipNo, photos[],
              genetics[{test,result,byParentage}], hips?,
              isExternal(bool — visiting stud), externalOwner?{name,phone,city},
              heats[{startedAt}], nextHeatPredicted (= last heat + 6 mo, editable)
Litter        id, code("2024-05"), name, damId→Dog, sireId→Dog,
              status(planned|pregnant|born|closed|did_not_take),
              dates: per key date {predicted: computed, actual: manual?},   // actual wins
              whelpingLog[{ts, type(born|stillborn), puppyId?, note?}]
TaskTemplate  id, name, phase, anchor(ovulation|mating|whelping|handover),
              offsetDays, durationDays, repeat{every,count}?
Task          id, litterId, templateId?, name, phase(prewhelp|t1_birth|t2_wean|t3_social),
              startDate, dueDate, status(todo|doing|done), assigneeIds[],
              isPinnedDate, anchorMode(fixed | anchor+offset), notes, comments[],
              checklist[{label,done}]?, costExpected(bool),
              resultLog{type(progesterone|weight|ultrasound|note), value, unit}?
Puppy         id, litterId, name, litterAffix, sex, color, birthDateTime, birthWeight,
              chipNo, regNo(LŠVK), photos[], genetics[{test, result, byParentage}],
              weighLog[{ts, grams, session(am|pm)}],
              status(available|reserved|coowned|export|deceased),
              handover{contractSigned, paymentComplete, chipRegistered,
                       passportGiven, handedOverAt?},
              ownerId?
Owner         id, spaceId, name, address, phone, email, country,
              payments[{amount, date, kind(deposit|final), method}], fullPrice,
              handoverDate, notes, waitingListFor?(litterId),
              dataSource(manual|link), linkFilledAt?      // reusable across litters
HealthEntry   id, litterId, type(vaccination|deworming|vet_check), product, date,
              appliesTo(all | puppyIds[]), byUserId       // renders into vet passport
Payer         id, spaceId, label("Andrius · SEB","Cash"…), ownerUserId?
Expense       id, litterId, date, description,
              category(vet_tests|travel|food|lodging|mating|documents|supplies|other),
              amountEur, payerId, receiptPhoto?, taskId?
Document      id, puppyId, type(sale_lt|sale_en|coown|export|mating),
              fieldValues{}, missingFields[], status(draft|ready|sent|signed|submitted|approved),
              history[{ts,event,byUserId}], pdfUrl?       // immutable render, view-only
Upload        id, spaceId, litterId?, puppyId?, ownerId?, file(pdf|img), name, byUserId, taskId?
Notification  id, userId, kind, refId, readAt?
```

## Scheduling engine (from the kennel's spreadsheet)

Formulas (predicted values):
- ovulation = heatStart + 13 d  (confirmed by progesterone ≥ ~18–20 nmol/l)
- 2nd mating ("15th day") = ovulation + 2 d
- whelping = mating + 59–60 d  (≈ ovulation + 63 d)
- puppies 8 weeks = birth + 56 d
- handover = birth + 2 months
- next heat (Dog) = last heat + 6 mo

Rules:
- Every key date is a pair `{predicted, actual?}` — **actual overrides predicted**.
- Creating a litter starts from a Dog record (dam prefills genetics/reg; heat start defaults from logged heat) and instantiates all TaskTemplates: startDate = anchorDate + offsetDays (~78 tasks, 4 phases). Manual tasks anytime (fixed date OR anchor+offset).
- **Cascade:** entering/editing an actual date re-shifts every task derived from that anchor, except `isPinnedDate` tasks. Show shift preview ("64 dates re-shift") before applying; emit `plan_shift`.
- Task completion sheet logs results (progesterone value ≥ threshold prompts "confirm ovulation" → cascade; ultrasound negative prompts **end plan**, below).
- **End plan (did_not_take):** cancels open tasks, keeps record + expenses, logs the heat on the Dog, predicts next heat, one `litter_cancelled` push.
- **Birth log:** opening it fires `whelping_started` push; entries born|stillborn; finishing sets actual birth date → cascade; weigh-in schedule begins.
- Gantt: drag bar → reschedule; same-anchor tasks optionally shift together; long-press → reassign.
- Weight alert: gain ≤ 5 g over 4 consecutive logs → notify all.
- Handover gate: puppy can be marked handed over only when checklist complete (contract signed, payment complete per Owner.payments vs fullPrice, chip registered, passport given).
- Litter close-out: requires all puppies handed over/retained; shows spent vs received; archive = read-only.

## Push notifications (FCM; in-app feed mirrors every push)
```
assigned         → assignee, immediate
due              → assignee, 07:00 due day + 1 day before
overdue          → assignee, daily 07:00
milestone        → all, 7 d & 1 d before anchor
comment          → task participants
weight_alert     → all, immediate
plan_shift       → all, on cascade
invite_joined    → all, immediate
heat_watch       → all, 14 d before Dog.nextHeatPredicted (deep-link: wizard prefilled)
whelping_started → all, when birth log opened
litter_cancelled → all, on end-plan
```
Rule values editable in space Settings (10f); per-user toggles on My profile (10g).

## Documents
- 5 built-in templates (from the kennel's DOCX files): Sale LT, Sale EN, Co-ownership, Export, Mating.
- Prefill map: Litter (breeder, kennel, dam/sire) + Puppy (name+affix, sex, color, chip, LŠVK reg no) + Owner (name, address, phone) + kennel data (price, handover date).
- Export contracts additionally require manual destination fields.
- Missing fields listed before generation; output = PDF; **view-only** (download/share/print). Regenerate after record edits. Status timeline per document.
- Vet passport: HealthEntry log renders per-puppy into a printable passport annex.
- Ad-hoc uploads (PDF/photo) attach to litter, puppy, or owner.

## Auth & space
- Email + password sign-up → **create kennel space** step (kennel name, affix, breeder details → feed contracts) or invite link → sign-up lands directly in the space.
- Invite link: signed token, 7-day expiry, rotatable. Forgot password: email link, 1 h expiry.
- Biometric unlock after first login. Refresh-token sessions, 30 d. One shared space, no roles in MVP.

## Expenses
- Categories match the kennel's Išlaidos sheet; payer = shared editable dropdown (any member adds).
- Create manually (10c) or from task completion (4a): category auto-suggested, last payer preselected; optional receipt photo + task link.
- Aggregates: total per litter, per category, per payer, cost-per-puppy; spent vs received on close-out. CSV export.

## Platform notes
- Dashboard stacks one card per active litter (multiple pregnant bitches).
- Night mode (dim dark theme, large targets) on birth log + weigh-in.
- Offline: weigh-ins & birth-log entries queue locally, sync on reconnect.
- Naming helper: soft warning when puppy name doesn't start with the litter letter.
- Global search across puppies, owners, tasks, documents.

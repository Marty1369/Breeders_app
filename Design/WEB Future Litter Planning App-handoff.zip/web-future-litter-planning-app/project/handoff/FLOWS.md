# Navigation & Flows (v1.6)

Visual versions: screen 9a (navigation map) and 12a (lifecycle map) in `Litter App Design.dc.html`.

## Navigation model
- **Bottom bar (only primary nav):** Timeline · Puppies · Docs · Expenses · Menu
- **Logo top-left on every screen → Home dashboard** (2b). No burger/drawer.
- Home extras: bell → Notifications (2j); FAB + → New litter (2f) / quick task (10b) / quick expense (10c)
- Menu tab (7a): litter switcher (10h), My dogs (12b), Owners (5a), People (2l), Notifications (2j), Settings (10f), profile (10g), sign out
- Pattern: full pages for destinations; bottom sheets for in-context actions (2e, 4a, 10b, 10c, 10d, 11d, 12c, 10h); dialogs only for destructive confirms. Everything ≤ 2 taps from Home.

## Lifecycle journeys (stage · flow)
0. **Between litters:** My dogs 12b tracks heats → `heat_watch` push 14 d before predicted → tap opens wizard 2f prefilled with the dam
1. **Set up (first run):** 2a sign up → 11a create kennel space → 10i empty state → 2f wizard → ~78 tasks appear in 2c/2d
2. **Invite team:** Menu → People 2l → copy link → teammate opens 2k → joins space
3. **Heat → mating:** progesterone tasks → results via 4a (value ≥ threshold → confirm ovulation → cascade) → dates visible in 10a
4. **Pregnancy check:** ultrasound task → 4a result "pregnant" (continue) OR "not pregnant" → 12c end plan (cancel tasks, keep expenses, log heat, `litter_cancelled`)
5. **Whelping night:** open birth log 11b (`whelping_started` push) → log each pup born/stillborn → finish → actual birth date set → cascade → T1 unlocks
6. **Rearing:** weigh-in 10d 2×/day (offline queue, flat-weight alert) · health log 11c → vet passport · photos/chips via 2h/4c
7. **Selling:** waiting list → reserve (5a/5b) → payments logged on owner → contract 2i → missing fields → PDF 4b → status timeline
8. **Handover:** per-puppy checklist 11d gates "handed over" (contract, payment, chip, passport)
9. **Close:** 11e close-out — spent vs received, warnings → read-only archive → dam back to stage 0
- **Anytime:** daily loop 2b → 2c/2d → 2e/4a · money 3e ← 4a/10c · search 11f · date correction 10a with cascade preview

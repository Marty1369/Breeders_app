# Product Decisions (resolved, v1.6)

1. **Visual direction:** "Clinical" — white, data-first, green accent `#17805a`.
2. **Navigation:** bottom tabs only; drawer removed. Bar = Timeline · Puppies · Docs · Expenses · Menu. Home tab removed — logo top-left returns to dashboard.
3. **People ≠ Owners:** People = space members (workers/associates) who log in and get push. Owners = contact records attached to puppies/litters — **not app users, never notified in MVP**. People screen tabs: "In this space" / "Owners".
4. **No roles in MVP.** Invite via rotating link. Keep `role` field for future RBAC.
5. **Documents are view-only PDFs.** Fix data in records, regenerate. Tap-to-fill editor (3a) superseded.
6. **Dates:** predicted (formula) + actual (manual, wins). Manual entry triggers cascade with preview; pinned tasks don't move.
7. **Expenses:** attachable at task completion or manual; payers = shared editable dropdown.
8. **Dogs are first-class records** (v1.6): litters reference Dog entities; heat history drives next-heat prediction + `heat_watch` push; external studs supported.
9. **Sad paths are designed** (v1.6): litter `did_not_take` (end-plan flow keeps expenses & logs heat), stillborn birth-log entries, puppy `deceased` status (record kept, excluded from counts).
10. **Lifecycle gates:** handover requires per-puppy checklist complete; close-out requires all puppies resolved and shows spent vs received; archives are read-only.
11. **MVP scope:** IN — auth + create-space + invites, dashboard (multi-litter), timeline list/gantt, task sheets + results + cascade, my dogs, puppies (weights/genetics/photos), birth log, health log, handover checklist, close-out, owners + payments, 5 doc templates → view-only PDF, uploads, expenses, push, search, settings/profile/switcher/empty/forgot. OUT (V2) — public buyer link & informing owners, e-sign, template upload/mapping, roles, multi-space, CSV import.

# Screen Inventory (v1.6)

Ids reference `Litter App Design.dc.html`. Type: **P** = full page, **S** = bottom sheet, **W** = wizard step.

## Auth & onboarding
| id | screen | type | notes |
|----|--------|------|-------|
| 2a | Login / Sign up | P | segmented Sign in / Sign up; fingerprint; invite-link hint |
| 11a | Create kennel space | W | post-sign-up: kennel name, affix, breeder details → feed contracts |
| 2k | Join via invite | P | invited user signs up straight into the space |
| 10j | Forgot password | P | email reset link, 1 h expiry |
| 10i | Empty state / first run | P | "Start first litter" + "Invite your team first" |

## Hub & navigation
| 2b | Home dashboard | P | one card per active litter; today's tasks; bell → 2j; FAB + |
| 7a | Menu tab | P | litter switcher, My dogs, Owners, People, Notifications, Settings, profile |
| 8a | Final bottom bar | — | Timeline · Puppies · Docs · Expenses · Menu; logo top-left = home |
| 10h | Litter switcher | S | active / planned / closed(archive) / did-not-take / + new |
| 11f | Global search | P | puppies, owners, tasks, docs across all litters |

## Dogs (breeding stock)
| 12b | My dogs | P | dam/sire registry: heat history, next-heat prediction + push, genetics, litter counts, external studs |

## Timeline & tasks
| 2c | Timeline — List | P | week groups, NOW marker, milestones, overdue highlight |
| 2d | Timeline — Gantt | P | drag to reschedule, NOW + milestone lines, phase filter |
| 2e | Task detail | S | auto-schedule rule, dates, status, assignees, notify, comments, checklist |
| 4a | Complete task | S | result log (progesterone → confirm ovulation → cascade) + attach expense |
| 10b | Create / edit task | S | fixed date OR anchor+offset, phase, assignees, repeat |
| 12c | Failed pregnancy | S | ultrasound negative → end plan: cancel tasks, keep expenses, log heat |
| 10a | Litter info & dates | P | AUTO (formula) + MANUAL (M) pairs; manual wins; cascade preview |

## Whelping & rearing
| 11b | Whelping birth log | P | live log born/stillborn vs expected; night-friendly; finish → actual birth date + cascade |
| 10d | Weigh-in mode | S | whole litter one pass, AM/PM, numpad, auto-advance; offline queue |
| 11c | Health log | P | vaccination/deworming whole litter in one entry; → vet passport |

## Puppies
| 2g | Puppies list | P | weight + sparkline, watch alerts, weigh-in entry |
| 2h | Puppy profile | P | photos, identity, genetics, weight chart, generate contract |
| 4c | Puppy record edit | P | name (litter-letter helper), sex/color, affix, LŠVK, chip, owner link |
| 11d | Handover checklist | S | gate: contract signed · payment complete · chip registered · passport |

## Documents
| 2i | Docs tab | P | central record, per-puppy contract grid, missing-fields list |
| 4b | PDF viewer | P | view-only; download/share/print; "fix in record → regenerate" |
| 10e | Docs + uploads | P | upload PDF/photo → litter/puppy/owner; filters |

## Expenses
| 3e | Expenses tab | P | totals, per-puppy, category bar, month groups, CSV |
| 10c | Add expense | S | amount, category chips, payer dropdown (+ new), receipt, task link |

## People & owners
| 2l | People | P | tabs: In this space (workers) / Owners; invite by link; workload |
| 5a | Owners list | P | search, litter filter, waiting list, missing-data filter |
| 5b | Owner record | P | contact data + kennel data (payments, price, handover, notes) |

## Lifecycle close
| 11e | Litter close-out | P | puppies, tasks, spent vs received, warnings, read-only archive |

## System
| 2j | Notifications | P | grouped feed; mirrors every push |
| 10f | Settings | P | kennel, affix, plan template, formula offsets, notif rules |
| 10g | My profile | P | account, per-user notif toggles, biometric, sign-out-all |
| 2f | New litter wizard | W | starts from Dog record; key dates; template note |

## Maps
| 9a | Navigation flow map | — | every screen + connection |
| 12a | Lifecycle map | — | 7 stages: actions / screens / automatics |

## V2 (designed, out of MVP)
3a tap-to-fill contract editor (superseded by view-only 4b) · 3b registry communication flow · 3c public buyer link · 3d template upload/mapping

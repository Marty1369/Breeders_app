# Litter Planner — UI kit

High-fidelity recreation of the **Litter Planner** app (a responsive kennel-management PWA for planning dog litters). The live, fully interactive source is `Litter Planner App.dc.html` at the project root — this kit captures its look with the shared tokens and components.

## Product shape
- **Two-tier navigation.** Top level = kennel-wide: Dashboard, Litters, All documents, All buyers, All expenses, My dogs. Second level = the *active litter's* scoped views: Calendar, Tasks, Repeating, Weigh-ins, Puppies, Documents, Buyers, Expenses.
- **Litters are the top of the hierarchy.** Every puppy, buyer, document, expense, task and recurring rule belongs to one litter. New litters instantiate a default task template + default documents, with all dates computed from the heat/whelping date.
- **Responsive.** Desktop = sidebar + content. Mobile (<760px) = bottom tab bar (Today / Plan / Litter / More) + FAB.

## Screens in the live app
Dashboard · Litters list & detail (dam/sire health records) · Calendar (month + day panel) · Tasks · Repeating rules (adherence history) · Weigh-ins (gram entry, sparklines, weight alert) · Puppies (status + handover gate) · Buyers (payments) · Expenses (categories) · Documents (status flow + attach file) · My dogs (heat & breeding math).

## Files
- `index.html` — desktop dashboard recreation (this kit's card + a Starting Point).

## Building on it
Compose the shared primitives — `Button`, `Card`, `StatusPill`, `CheckRow`, `Toggle`, `ChipToggle`, `SegmentedControl`, `Avatar`, `ProgressBar` — over the `styles.css` tokens. Don't reimplement them here.
